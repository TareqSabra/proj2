/**
 * Example "Money" for JUnit v3.x.
 */
package junit.samples.money;